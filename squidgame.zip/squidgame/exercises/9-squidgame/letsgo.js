"use strict";
import context from "../../scripts/context.js";
import * as Utils from "../../scripts/utils.js";

let width = context.canvas.width;
let height = context.canvas.height;

let isPlaying = true;

let xDoll = width / 2;
let yDoll = 75;

let x = width / 2 - 200;
let y = height - 75;
let speed = 5;

context.textAlign = "center";
context.font = "bold 100pt Arial";
document.onkeydown = movePlayer;

setup();

function setup() {
    if (isPlaying) {
        drawLocation();
        drawPlayer()
        lookMovement();
        requestAnimationFrame(setup);
    }
}

/**
 * 
 * @param {KeyboardEvent} e 
 */
function movePlayer(e) {
    if (e.key == "ArrowUp") {
        if (y <= 120) {
            isPlaying = false;
            context.fillStyle = "green";
            context.fillText("You Win", width / 2, height / 2)
        }
        let d = new Date().getSeconds();
        if (e.key == "ArrowUp" && d % 8 == 0) {
            showYouLose();
        }
        y -= speed;
    }
}

function showYouLose() {
    isPlaying = false;
    context.fillStyle = "red";
    context.fillText("You Lose", width / 2, height / 2)
}

function lookMovement() {
    let d = new Date().getSeconds();
    if (d % 8 == 0) {
        isLooking()
    } else {
        notLooking()
    }
}


function drawLocation() {
    context.fillStyle = "#FFFC93";
    context.fillRect(0, 0, width, height);
    context.fillStyle = "#FF5EA5";
    context.fillRect(0, 130, width, 20);
}



function isLooking() {
    context.fillStyle = "#FF5500";
    Utils.fillCircle(xDoll, yDoll, 50);
    context.fillStyle = "black";
    Utils.fillCircle(xDoll, yDoll, 30);
    Utils.fillCircle(xDoll - 30, yDoll - 25, 15);
    Utils.fillCircle(xDoll + 30, yDoll - 25, 15);
}

function notLooking() {
    context.fillStyle = "#FF5500";
    Utils.fillCircle(xDoll, yDoll, 50);
    context.fillStyle = "black";
    Utils.fillCircle(xDoll, yDoll, 30);
    Utils.fillCircle(xDoll - 30, yDoll + 25, 15);
    Utils.fillCircle(xDoll + 30, yDoll + 25, 15);
}


function drawPlayer() {
    context.fillStyle = "darkgreen";
    Utils.fillCircle(x, y, 30);
    Utils.fillCircle(x - 30, y, 20);
    Utils.fillCircle(x + 30, y, 20);
    context.fillStyle = "black";
    Utils.fillCircle(x, y, 20);


}